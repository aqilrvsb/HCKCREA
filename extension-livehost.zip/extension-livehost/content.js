/**
 * TikTok AI Live Host — Content Script
 *
 * 100% based on tiktok-live-reply v1.5.2 content.js
 * Watches TikTok Shop Live chat for new comments and join events.
 * Handles POST_REPLY (typing into chat) for Auto Reply mode.
 */

(async function () {
  console.log("[AI Host] Content script loaded on:", window.location.href);

  const url = window.location.href.toLowerCase();
  if (!url.includes("shop.tiktok.com/streamer/live")) {
    console.log("[AI Host] Not a TikTok Shop live page, exiting");
    return;
  }

  console.log("[AI Host] TikTok Shop live page detected, waiting 15s for page to fully load...");
  await new Promise(r => setTimeout(r, 15000));

  // Validate shop username against PeningBot registered accounts
  const { tiktokAccounts } = await chrome.storage.local.get("tiktokAccounts");
  if (tiktokAccounts && tiktokAccounts.length > 0) {
    const navUsername = document.querySelector('span.text-body-s-medium[class*="text-white"]');
    const shopUser = navUsername ? navUsername.textContent.trim().toLowerCase() : "";
    console.log("[AI Host] Shop username:", shopUser, "| Allowed accounts:", tiktokAccounts);

    if (shopUser && !tiktokAccounts.some(acc => acc.toLowerCase() === shopUser)) {
      console.log("[AI Host] Username mismatch! Stopping and closing tab.");
      alert("Username TikTok Shop (" + shopUser + ") tidak sepadan dengan akaun yang didaftarkan di PeningBot.\n\nAkaun berdaftar: " + tiktokAccounts.join(", ") + "\n\nTab akan ditutup dalam 5 saat.");
      try { chrome.runtime.sendMessage({ type: "STOP" }); } catch(e) {}
      setTimeout(() => { window.close(); }, 5000);
      return;
    }
  }

  console.log("[AI Host] Initializing...");
  initLiveHost();
  setupAutoPin();
  setupLiveTimer();
})();

// ============================================================================
// AUTO-PIN: keep the FEATURED product pinned + re-pin it every N seconds so the
// product popup re-shows to viewers (a common live-selling tactic). Operates on
// the FIRST product in the list (put your target product at the top). TikTok
// needs an UNPIN before a re-PIN, so a re-bump = unpin → (1.5s) → pin.
// Controlled by chrome.storage.local: lhAutoPin (bool) + lhAutoPinSec (default 15).
// ============================================================================
function setupAutoPin() {
  let autoPinTimer = null;

  // TikTok's arco buttons often ignore a bare .click() (their React listens on
  // pointer/mouse events) — fire a full realistic sequence + .click() fallback.
  function realClick(el) {
    if (!el) return false;
    try {
      const o = { bubbles: true, cancelable: true, view: window };
      el.dispatchEvent(new PointerEvent("pointerdown", o));
      el.dispatchEvent(new MouseEvent("mousedown", o));
      el.dispatchEvent(new PointerEvent("pointerup", o));
      el.dispatchEvent(new MouseEvent("mouseup", o));
      el.dispatchEvent(new MouseEvent("click", o));
    } catch (e) {}
    try { el.click(); } catch (e) {}
    return true;
  }

  function tick() {
    const first = document.querySelector(".pc_pin_product_pin, .pc_pin_product_unpin");
    if (!first) { console.log("[AI Host] auto-pin: product pin button NOT found (right page? products loaded?)"); return; }
    if (first.classList.contains("pc_pin_product_unpin")) {
      // Already pinned → unpin, then re-pin the same (top) product to re-bump.
      console.log("[AI Host] auto-pin: re-bump (unpin → 1.5s → pin)");
      realClick(first);
      setTimeout(() => {
        const pin = document.querySelector(".pc_pin_product_pin");
        if (pin) realClick(pin);
        else console.log("[AI Host] auto-pin: pin button missing after unpin");
      }, 1500);
    } else {
      console.log("[AI Host] auto-pin: pinning first product");
      realClick(first); // not pinned yet → pin it
    }
  }

  // Pin config comes from the dashboard greeting (Pin Min/Max), fetched on START
  // → stored as lhPinMin/lhPinMax. Auto-pin runs WHILE LIVE (lhRunning) and
  // re-pins at a RANDOM interval in [min,max] seconds (looks natural).
  function scheduleNext(lo, hi) {
    const sec = Math.round(lo + Math.random() * (hi - lo));
    autoPinTimer = setTimeout(() => { tick(); scheduleNext(lo, hi); }, sec * 1000);
    console.log("[AI Host] auto-pin: next in", sec, "s");
  }
  async function refresh() {
    const { lhRunning, lhPinMin, lhPinMax } = await chrome.storage.local.get(["lhRunning", "lhPinMin", "lhPinMax"]);
    if (autoPinTimer) { clearTimeout(autoPinTimer); autoPinTimer = null; }
    if (!lhRunning) { console.log("[AI Host] Auto-pin OFF (not live)"); return; }
    const lo = Math.max(5, Number(lhPinMin) || 30);
    const hi = Math.max(lo, Number(lhPinMax) || 90);
    tick();              // pin once now
    scheduleNext(lo, hi); // then re-pin at random intervals
    console.log("[AI Host] Auto-pin ON — random", lo, "-", hi, "s");
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && ("lhRunning" in changes || "lhPinMin" in changes || "lhPinMax" in changes)) refresh();
  });
  refresh();
}

// ============================================================================
// LIVE DURATION TIMER — auto-end the TikTok LIVE after the set duration.
// The side panel writes lhLiveEndAt (epoch ms) to storage on START. This watcher
// (on the TikTok tab) checks every few seconds; when the deadline passes it
// clicks the LIVE power-off button → waits for the "End LIVE?" modal → Confirm.
// lhLiveEndAt is cleared after firing (and on STOP) so it never double-ends.
// ============================================================================
function findEndLiveButton() {
  // 1) The power-off icon (TikTok's End-LIVE control) — primary.
  const svg = document.querySelector("svg.arco-icon-im_close_chat");
  if (svg) return svg.closest("div.cursor-pointer") || svg.parentElement;
  // 2) Fallback: a button/clickable with End-LIVE text (EN/MS variants).
  const re = /^(end live|end|tamat(kan)?( live)?|akhiri( live)?|stop live)$/i;
  const cand = [...document.querySelectorAll('button, [role="button"], div.cursor-pointer, span')]
    .find((el) => re.test((el.innerText || "").trim()));
  return cand || null;
}

function endLiveNow() {
  const btn = findEndLiveButton();
  if (!btn) { console.log("[AI Host] End-LIVE button not found"); return false; }
  console.log("[AI Host] Duration reached → ending LIVE");
  btn.click();
  // Wait for the "End LIVE?" confirm modal, then click Confirm (never Cancel).
  let tries = 0;
  const iv = setInterval(() => {
    tries++;
    const modal = document.querySelector(".arco-modal");
    if (modal && /end live/i.test(modal.textContent || "")) {
      const confirm = [...modal.querySelectorAll("button")].find(
        (b) => /confirm/i.test(b.textContent || "") || b.classList.contains("arco-btn-primary")
      );
      if (confirm) { confirm.click(); console.log("[AI Host] LIVE end confirmed"); clearInterval(iv); return; }
    }
    if (tries > 30) clearInterval(iv); // ~9s give-up
  }, 300);
  return true;
}

function setupLiveTimer() {
  let fired = false;
  async function check() {
    const { lhLiveEndAt } = await chrome.storage.local.get("lhLiveEndAt");
    if (!lhLiveEndAt || fired) return;
    if (Date.now() >= Number(lhLiveEndAt)) {
      fired = true;
      await chrome.storage.local.remove("lhLiveEndAt"); // one-shot
      endLiveNow();
      try { chrome.runtime.sendMessage({ type: "LIVE_ENDED" }); } catch (e) {}
    }
  }
  // Reset the one-shot guard whenever a new end-time is scheduled (next START).
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && "lhLiveEndAt" in changes && changes.lhLiveEndAt.newValue) fired = false;
  });
  setInterval(check, 5000);
  check();
}

function initLiveHost() {
  // ============================================================================
  // DOM SELECTORS — proven from tiktok-live-reply v1.5.2
  // ============================================================================

  const SELECTORS = {
    chatContainer: '.arco-list-content.arco-list-virtual',
    chatMessage: '.rounded-8.relative',
    joinMessage: '.rounded-l-16',
    chatItem: '[type="view_filter"]',
    // TikTok uses text-body-m-medium (fullscreen) or text-body-s-medium (small window)
    commentUsername: '.text-neutral-text3[class*="text-body"][class*="-medium"]',
    commentText: '.text-neutral-text1.pl-32',
    hostBadge: '.arco-tag',
    chatInput: 'textarea[data-tid="m4b_input_textarea"]',
    sendButton: '.arco-icon-publish'
  };

  // ============================================================================
  // STATE
  // ============================================================================

  const recentComments = new Set();
  const MAX_DEDUP = 200;
  let scanInterval = null;
  let keepaliveInterval = null;
  let containerRef = null;

  // ============================================================================
  // CHAT CONTAINER
  // ============================================================================

  function findAllContainers() {
    return document.querySelectorAll(SELECTORS.chatContainer);
  }

  // ============================================================================
  // MESSAGE EXTRACTION
  // ============================================================================

  function isHostMessage(msgNode) {
    const tags = msgNode.querySelectorAll(SELECTORS.hostBadge);
    for (const tag of tags) {
      if (tag.textContent.trim() === "Host") return true;
    }
    return false;
  }

  function extractSingleComment(msgNode) {
    if (isHostMessage(msgNode)) return null;

    const usernameEl = msgNode.querySelector(SELECTORS.commentUsername);
    if (!usernameEl) return null;
    const commenter = usernameEl.textContent.trim();
    if (!commenter) return null;

    // Check if this is a join event — "Username just joined" has no .pl-32 text element
    // The full text of the parent span contains "just joined" or "joined the live"
    const parentText = msgNode.textContent || "";
    const parentLower = parentText.toLowerCase();
    if (parentLower.includes("join")) {
      return { type: 'join', username: commenter };
    }

    if (parentLower.includes("follow")) {
      return { type: 'follow', username: commenter };
    }

    if (parentLower.includes("like")) {
      return { type: 'like', username: commenter };
    }

    const textEl = msgNode.querySelector(SELECTORS.commentText);
    if (!textEl) return null;
    const text = textEl.textContent.trim();
    if (!text) return null;

    // Filter out @mentions
    if (text.startsWith("@")) return null;

    return { type: 'comment', username: commenter, text };
  }

  function safeSendMessage(msg) {
    try { chrome.runtime.sendMessage(msg).catch(() => {}); } catch (e) {}
  }

  // ============================================================================
  // LIVE ENDED DETECTION
  // ============================================================================

  function isLiveEnded() {
    const modal = document.querySelector('.arco-modal');
    if (modal && modal.textContent.includes("Cheers to completing another LIVE")) {
      return true;
    }
    return false;
  }

  // ============================================================================
  // POLLING: Scan last 5 messages every 1 second
  // ============================================================================

  function scanLatestMessages() {
    if (isLiveEnded()) {
      console.log("[AI Host] Live ended, auto-stopping...");
      cleanup();
      safeSendMessage({ type: "LIVE_ENDED" });
      return;
    }

    // Scan ALL virtual list containers (Chat panel + Activity panel)
    const containers = findAllContainers();
    if (containers.length === 0) return;

    for (const container of containers) {
      // Select both comments (.rounded-8.relative) and joins (.rounded-l-16)
      const allMsgs = container.querySelectorAll(`${SELECTORS.chatMessage}, ${SELECTORS.joinMessage}`);
      const total = allMsgs.length;
      const startIdx = Math.max(0, total - 5);

      for (let i = startIdx; i < total; i++) {
        const data = extractSingleComment(allMsgs[i]);
        if (!data) continue;

        if (data.type === 'join') {
          const joinKey = `join:${data.username}`;
          if (recentComments.has(joinKey)) continue;
          recentComments.add(joinKey);
          if (recentComments.size > MAX_DEDUP) {
            const first = recentComments.values().next().value;
            recentComments.delete(first);
          }
          console.log("[AI Host] New join:", data.username);
          safeSendMessage({
            type: 'USER_JOINED',
            username: data.username
          });
          continue;
        }

        if (data.type === 'follow') {
          const followKey = `follow:${data.username}`;
          if (recentComments.has(followKey)) continue;
          recentComments.add(followKey);
          if (recentComments.size > MAX_DEDUP) {
            const first = recentComments.values().next().value;
            recentComments.delete(first);
          }
          console.log("[AI Host] New follow:", data.username);
          safeSendMessage({
            type: 'USER_FOLLOWED',
            username: data.username
          });
          continue;
        }

        if (data.type === 'like') {
          const likeKey = `like:${data.username}`;
          if (recentComments.has(likeKey)) continue;
          recentComments.add(likeKey);
          if (recentComments.size > MAX_DEDUP) {
            const first = recentComments.values().next().value;
            recentComments.delete(first);
          }
          console.log("[AI Host] New like:", data.username);
          safeSendMessage({
            type: 'USER_LIKED',
            username: data.username
          });
          continue;
        }

        // Comment dedup
        const key = `${data.username}:${data.text}`;
        if (recentComments.has(key)) continue;

        recentComments.add(key);
        if (recentComments.size > MAX_DEDUP) {
          const first = recentComments.values().next().value;
          recentComments.delete(first);
        }

        console.log("[AI Host] New comment:", data.username, ":", data.text);
        safeSendMessage({
          type: 'NEW_COMMENT',
          username: data.username,
          text: data.text
        });
      }
    }
  }

  // ============================================================================
  // START
  // ============================================================================

  let retries = 0;

  function start() {
    const containers = findAllContainers();
    if (containers.length === 0) {
      retries++;
      if (retries % 15 === 0) {
        console.log("[AI Host] Still waiting for chat containers... retry", retries);
      }
      setTimeout(start, 2000);
      return;
    }

    console.log("[AI Host] Found", containers.length, "chat/activity containers");

    // Mark existing COMMENTS so we don't process them (but NOT joins — we want to greet)
    for (const container of containers) {
      const existing = container.querySelectorAll(SELECTORS.chatMessage);
      console.log("[AI Host] Existing comments in container:", existing.length);
      existing.forEach(msg => {
        const data = extractSingleComment(msg);
        if (data && data.type === 'comment') {
          recentComments.add(`${data.username}:${data.text}`);
        }
      });
    }

    // Poll every 1s, scan last 5 messages
    scanInterval = setInterval(scanLatestMessages, 1000);
    console.log("[AI Host] Polling started (every 1s, last 5 messages)");

    // Keepalive ping every 25s
    keepaliveInterval = setInterval(() => {
      safeSendMessage({ type: 'KEEPALIVE' });
    }, 25000);
  }

  function cleanup() {
    if (scanInterval) clearInterval(scanInterval);
    if (keepaliveInterval) clearInterval(keepaliveInterval);
    scanInterval = null;
    keepaliveInterval = null;
  }

  // ============================================================================
  // AUTO REPLY: Type into chat and send
  // ============================================================================

  function findChatInput() {
    return document.querySelector(SELECTORS.chatInput);
  }

  function findSendButton() {
    const icon = document.querySelector(SELECTORS.sendButton);
    if (icon) return icon.closest('span') || icon.parentElement;
    return null;
  }

  async function postReplyToChat(text, commenter) {
    const fullReply = `@${commenter} ${text}`;
    const truncated = fullReply.substring(0, 100);

    const input = findChatInput();
    if (!input) {
      console.log("[AI Host] Chat input NOT found!");
      safeSendMessage({ type: "REPLY_POSTED", success: false, replyText: truncated });
      return;
    }

    console.log("[AI Host] Chat input found, typing:", truncated);

    input.focus();
    await new Promise(r => setTimeout(r, 100));

    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLTextAreaElement.prototype, 'value'
    ).set;
    nativeInputValueSetter.call(input, truncated);

    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));

    await new Promise(r => setTimeout(r, 500));

    console.log("[AI Host] Pressing Enter to send");
    input.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Enter", code: "Enter", keyCode: 13, bubbles: true
    }));
    input.dispatchEvent(new KeyboardEvent("keypress", {
      key: "Enter", code: "Enter", keyCode: 13, bubbles: true
    }));
    input.dispatchEvent(new KeyboardEvent("keyup", {
      key: "Enter", code: "Enter", keyCode: 13, bubbles: true
    }));

    await new Promise(r => setTimeout(r, 300));
    if (input.value && input.value.length > 0) {
      console.log("[AI Host] Enter didn't clear input, trying send button");
      const sendBtn = findSendButton();
      if (sendBtn) sendBtn.click();
    }

    safeSendMessage({ type: "REPLY_POSTED", success: true, replyText: truncated });
  }

  // ============================================================================
  // MESSAGE LISTENER
  // ============================================================================

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "POST_REPLY") {
      console.log("[AI Host] Posting reply to", message.commenter, ":", message.text);
      postReplyToChat(message.text, message.commenter);
    }
    if (message.type === "STOP") {
      console.log("[AI Host] Stopped by user");
      cleanup();
    }
    if (message.type === "RESUME") {
      console.log("[AI Host] Resuming...");
      cleanup();
      retries = 0;
      start();
    }
  });

  start();
}
